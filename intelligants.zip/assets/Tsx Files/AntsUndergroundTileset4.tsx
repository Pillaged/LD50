<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="AntsUndergroundTileset4" tilewidth="32" tileheight="32" tilecount="64" columns="16">
 <image source="../AntsUndergroundTileset.png" width="512" height="144"/>
</tileset>
